export const PRODUCTS_PER_PAGE = 10;
export const ITEMS_PER_PAGE = 10;