import  brandMain from "./brand-main.jpeg"

export {
    brandMain
}