export type Financer = {
  id: number;
  name: string;
  contactName: string;
  phone: string;
  email: string;
  address: string;
  createdAt: string;
  updatedAt: string;
};
