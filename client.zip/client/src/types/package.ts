export type Package = {
  [x: string]: string;
  name: string;
  phone: string;
  role: string;
  email: string;
  id: string;
  id: string;

};

