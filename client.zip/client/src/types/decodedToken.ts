export type DecodedToken = {
    id: string;
    name: string;
    role: string;
    email:string;
    profileimage: string;
    workingstatus: string;
}
